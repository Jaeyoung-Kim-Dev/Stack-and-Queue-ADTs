1. A project title:
ADT and TDD - XML Parser

2. What the program does:
This application is parsing XML files with my own ADTs for a stack and a queue.

3. The date:
November 20, 2020

4. The author:
Jaeyoung Kim

5. How to run the program:
1) Run Command Prompt (CMD)
2) Change directory which includes the Parser.jar file.
3) Typle in the command lines with arguments like the example below.
4) Command examples
java -jar Parser.jar res/sample1.xml
java -jar Parser.jar res/sample2.xml